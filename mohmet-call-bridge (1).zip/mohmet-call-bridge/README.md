# MohMet Multilingual Calling MVP

Fast-start MVP for a 2-person metals trading team. The UI is a browser dialler and the backend starts outbound Telnyx calls. The language engine is deliberately provider-neutral so languages can be extended without changing the UI.

## Current architecture
- Next.js / TypeScript
- Telnyx for phone numbers and outbound PSTN
- OpenAI Realtime Translate for low-latency speech translation (wire this into the Telnyx media stream)
- MohMet trading glossary
- 31 initial languages

OpenAI currently lists `GPT-Realtime-Translate` as a dedicated realtime speech/translation model. See the current model catalogue: https://platform.openai.com/docs/models.

## Run
1. Copy `.env.example` to `.env.local`.
2. Add Telnyx credentials and a Telnyx number.
3. Set `PUBLIC_BASE_URL` to your public HTTPS URL.
4. `npm install`
5. `npm run dev`

## Important next wiring step
The included `/api/telnyx/webhook` receives Telnyx call events. The remaining production media bridge should:
1. answer/accept the call;
2. start a bidirectional Telnyx media stream;
3. send employee-side audio to an OpenAI realtime translation session targeting the supplier language;
4. send supplier-side audio to a second realtime translation session targeting English;
5. write returned PCM/µ-law audio back to the opposite Telnyx call leg;
6. persist transcript + summary after hangup.

This separation is intentional: PSTN remains Telnyx; translation remains OpenAI; MohMet owns the small control layer.

## Production notes
- Keep API keys server-side only.
- Add authentication before exposing the dialler publicly.
- Add a recording/consent policy before enabling recording/transcription across jurisdictions.
- Add a real contacts database (SQLite/Postgres) once the call path is verified.
