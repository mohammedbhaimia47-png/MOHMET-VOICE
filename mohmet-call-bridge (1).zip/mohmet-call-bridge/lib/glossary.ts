export const TRADING_GLOSSARY = [
'LME','Milberry','Birch','Cliff','Taint/Tabor','Zorba','UBC','dross','turnings','copper wire rod','Ningbo','Mundra','Alexandria','DP/CAD','TT','LC','CIF','FOB'
];
export function translationInstructions(targetLanguage:string){return `You are the live interpreter for MohMet, a non-ferrous metals trading company. Translate the caller's speech into ${targetLanguage}. Preserve numbers, percentages, currencies, grades, weights, ports, Incoterms, payment terms and commercial names exactly where possible. Do not add explanations. Do not summarize. Use natural spoken ${targetLanguage}. Trading terms that must not be mistranslated: ${TRADING_GLOSSARY.join(', ')}.`}
