export const LANGUAGES = [
['en','English'],['es','Spanish'],['pt','Portuguese'],['it','Italian'],['pl','Polish'],['fr','French'],['de','German'],['nl','Dutch'],['ru','Russian'],['uk','Ukrainian'],['ro','Romanian'],['el','Greek'],['cs','Czech'],['hu','Hungarian'],['sv','Swedish'],['da','Danish'],['no','Norwegian'],['fi','Finnish'],['sk','Slovak'],['bg','Bulgarian'],['hr','Croatian'],['sl','Slovenian'],['sr','Serbian'],['ar','Arabic'],['hi','Hindi'],['gu','Gujarati'],['ur','Urdu'],['tr','Turkish'],['zh','Mandarin Chinese'],['ja','Japanese'],['ko','Korean']
] as const;
export type LanguageCode = typeof LANGUAGES[number][0];
