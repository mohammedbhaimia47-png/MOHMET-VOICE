import {NextResponse} from 'next/server';
export async function POST(req:Request){
 const event=await req.json();
 // TODO: answer call, start bidirectional media stream, and connect each direction to OpenAI Realtime Translate.
 console.log('TELNYX_EVENT',JSON.stringify(event));
 return NextResponse.json({ok:true});
}
