import {NextResponse} from 'next/server';
import {z} from 'zod';
const schema=z.object({to:z.string().min(7),targetLanguage:z.string().min(2)});
export async function POST(req:Request){
 const body=schema.parse(await req.json());
 const key=process.env.TELNYX_API_KEY; const connection=process.env.TELNYX_CONNECTION_ID; const from=process.env.TELNYX_FROM_NUMBER; const base=process.env.PUBLIC_BASE_URL;
 if(!key||!connection||!from||!base)return NextResponse.json({error:'Missing Telnyx environment variables'}, {status:500});
 const r=await fetch('https://api.telnyx.com/v2/calls',{method:'POST',headers:{'Authorization':`Bearer ${key}`,'Content-Type':'application/json'},body:JSON.stringify({connection_id:connection,to:body.to,from,webhook_url:`${base}/api/telnyx/webhook`,webhook_url_method:'POST'})});
 const j=await r.json(); if(!r.ok)return NextResponse.json({error:j?.errors?.[0]?.detail||'Telnyx call creation failed',details:j},{status:r.status});
 return NextResponse.json({callControlId:j.data?.call_control_id,targetLanguage:body.targetLanguage});
}
