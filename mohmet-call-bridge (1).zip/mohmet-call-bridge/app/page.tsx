'use client';
import {useMemo,useState} from 'react';
import {LANGUAGES} from '../lib/languages';

type Contact={name:string;phone:string;language:string;country:string};
const demo:Contact[]=[
{name:'Egypt Supplier',phone:'+20 000 000 0000',language:'ar',country:'Egypt'},
{name:'China Buyer',phone:'+86 000 000 0000',language:'zh',country:'China'},
{name:'Spanish Supplier',phone:'+34 000 000 0000',language:'es',country:'Spain'}
];
export default function Home(){
 const [contacts]=useState(demo); const [selected,setSelected]=useState<Contact|null>(null); const [number,setNumber]=useState(''); const [language,setLanguage]=useState('ar'); const [calling,setCalling]=useState(false); const [lines,setLines]=useState<string[]>([]);
 const label=useMemo(()=>LANGUAGES.find(x=>x[0]===language)?.[1]??language,[language]);
 async function call(){const phone=number||selected?.phone;if(!phone)return;setCalling(true);setLines(l=>[...l,'Starting call…']);try{const r=await fetch('/api/call',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({to:phone,targetLanguage:language})});const j=await r.json();if(!r.ok)throw new Error(j.error||'Call failed');setLines(l=>[...l,`Call started: ${j.callControlId}`]);}catch(e){setLines(l=>[...l,`Error: ${e instanceof Error?e.message:'Unknown error'}`]);setCalling(false)}}
 async function hangup(){setCalling(false);setLines(l=>[...l,'Hang up requested.']);}
 return <main className="shell"><div className="top"><div><div className="brand">MohMet Multilingual Calling</div><div className="muted">Browser dialler • live interpretation • trading glossary</div></div><span className="pill">2 users</span></div>
 <div className="grid"><section className="card"><h2>Call</h2><div className="row"><input className="input" placeholder="+ country code and number" value={number} onChange={e=>setNumber(e.target.value)}/><select className="input" value={language} onChange={e=>setLanguage(e.target.value)}>{LANGUAGES.map(([c,n])=><option key={c} value={c}>{n}</option>)}</select></div><div className="section row">{!calling?<button className="btn primary" onClick={call}>Call in {label}</button>:<button className="btn danger" onClick={hangup}>End call</button>}</div><div className="status">{calling?`Live translation: English ↔ ${label}`:'Ready. Supplier does not need the app.'}</div><div className="section"><h3>Activity</h3><div className="transcript">{lines.length?lines.map((x,i)=><div key={i}>{x}</div>):<span className="muted">Call events and transcript will appear here.</span>}</div></div></section>
 <aside className="card"><h2>Contacts</h2>{contacts.map(c=><div className="contact" key={c.name}><div><b>{c.name}</b><div className="muted">{c.country} • {c.phone}</div></div><div className="row"><span className="lang">{LANGUAGES.find(x=>x[0]===c.language)?.[1]||c.language}</span><button className="btn" onClick={()=>{setSelected(c);setNumber(c.phone);setLanguage(c.language)}}>Use</button></div></div>)}<div className="section"><div className="muted">Supported now</div><p className="small">English, Spanish, Portuguese, Italian, Polish, French, German, Dutch, Russian, Ukrainian, Romanian, Greek, Czech, Hungarian, Swedish, Danish, Norwegian, Finnish, Slovak, Bulgarian, Croatian, Slovenian, Serbian, Arabic, Hindi, Gujarati, Urdu, Turkish, Mandarin Chinese, Japanese and Korean.</p></div></aside></div></main>
}
